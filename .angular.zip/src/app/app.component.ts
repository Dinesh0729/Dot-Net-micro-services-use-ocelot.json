import {  HTTP_INTERCEPTORS, provideHttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { authInterceptor } from './core/interceptors/auth.interceptor';
import { ErrorInterceptor } from './core/interceptors/error-interceptor';

@Component({
  selector: 'kz-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  providers: [
    // provideHttpClient(), 
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useValue: authInterceptor, multi: true },  // Register the auth interceptor globally
  ],
})
export class AppComponent {
  title = 'login-ui';
  
  
}
