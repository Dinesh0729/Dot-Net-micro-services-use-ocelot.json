import { provideAnimations } from '@angular/platform-browser/animations';
import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors, withFetch } from '@angular/common/http';
import { routes } from './app.routes';
import { authInterceptor } from './core/interceptors/auth.interceptor';
import { ErrorHandler, Provider } from '@angular/core';
import { GlobalErrorHandler } from './core/guards/global-error-handler';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

const globalErrorHandlerProvider: Provider = {
  provide: ErrorHandler,
  useClass: GlobalErrorHandler
};

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptors([authInterceptor]), withFetch()),
    provideAnimations(),   // Add this line
    globalErrorHandlerProvider, provideAnimationsAsync(),
  ]
};
