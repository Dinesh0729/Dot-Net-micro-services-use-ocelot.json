import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../../../../core/services/auth.service';
import { Router } from '@angular/router';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

@Component({
  selector: 'kz-login',
  standalone: true,
  imports: [CommonModule, FormsModule, MatInputModule, MatCardModule, MatButtonModule, MatSnackBarModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  processString: string = "Sign In";
  isLoading: boolean = false;  // For showing loading spinner

  constructor(
    private authService: AuthService,
    private router: Router,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {

  }


  // Handles login and subsequent API calls
  login() {
    this.isLoading = true;  // Show loading indicator
    this.processString = "Processing";

    this.authService.login({ username: this.username, password: this.password }).subscribe(
      (response) => {
        this.authService.saveToken(response.token); // Save the token

        const userData = {
          token: response.token,
          userId: response.userId,
          username: response.username,
          firstName: response.firstName,
          lastName: response.lastName
        };
        this.authService.saveUser(userData);
        this.router.navigate(['/dashboard']);
        this.isLoading = false;
      },
      (error) => {
        this.isLoading = false;
        this.processString = "Sign In";
        this.showError("Login failed", error);
      }
    );
  }

  // Method to display an error using MatSnackBar
  showError(message: string, error: any) {
    console.error(message, error);
    this.snackBar.open(message, 'Close', {
      duration: 5000,
      horizontalPosition: 'center',
      verticalPosition: 'top'
    });
  }

  navigateToRegister() {
    this.router.navigate(['/register']);
  }
}
