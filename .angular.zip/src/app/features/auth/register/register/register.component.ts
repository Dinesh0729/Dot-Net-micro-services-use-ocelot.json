import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { AuthService } from '../../../../core/services/auth.service';
import { Router } from '@angular/router';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

@Component({
  selector: 'kz-register',
  standalone: true,
  imports: [CommonModule, FormsModule, MatInputModule, MatCardModule, MatButtonModule,MatSnackBarModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss'
})
export class RegisterComponent {
  processString: string = "Register";
  firstName: string = '';
  lastName: string = '';
  username: string = '';
  password: string = '';
  emailId: string = '';

  constructor(private authService: AuthService, private router: Router,private snackBar: MatSnackBar) { }

  register() {
    this.authService.register({
      firstName: this.firstName,
      lastName: this.lastName,
      username: this.username,
      password: this.password,
      emailId: this.emailId
    }).subscribe(
      () => {
        this.router.navigate(['/login']);
      },
      (error) => {
        this.processString = "Loading";
        console.error('Registration failed', error);
        this.snackBar.open('Register failed: ' + error.message, 'Close', {
          duration: 5000,
          horizontalPosition: 'center',
          verticalPosition: 'top', 
        });
      }
    );
  }
  navigateTologin() {
    this.router.navigate(['/login']); 
  }
}
