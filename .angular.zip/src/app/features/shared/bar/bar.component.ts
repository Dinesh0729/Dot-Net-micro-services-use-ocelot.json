import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { MatCard, MatCardContent, MatCardTitle } from '@angular/material/card';

@Component({
  selector: 'kz-bar',
  standalone: true,
  imports: [MatCard, MatCardTitle, MatCardContent],
  templateUrl: './bar.component.html',
  styleUrl: './bar.component.scss'
})
export class BarComponent implements OnInit {
  @Input() username: any;
  ngOnInit(): void {
    console.log(this.username, 'name')
  }

}
