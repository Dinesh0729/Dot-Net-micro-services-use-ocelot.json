import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from '../../../layouts/header/header/header.component';
import { BarComponent } from '../../../features/shared/bar/bar.component';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SidenavComponent } from '../../../layouts/sidenav/shared/components/sidenav/sidenav.component';

@Component({
  selector: 'kz-user-dashboard',
  standalone: true,
  imports: [CommonModule, HeaderComponent, BarComponent,SidenavComponent],
  templateUrl: './user-dashboard.component.html',
  styleUrl: './user-dashboard.component.scss'
})
export class UserDashboardComponent implements OnInit {
  isDarkMode: boolean = false;
  username: string | null = null;
  menuList: any;
  modulesList: any[] = [];
  isLoading: boolean = false;
  selectedModuleName: string = ''; 
  isSidenavVisible: boolean = true;
  constructor(private router: Router, public authService: AuthService, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    const user = this.authService.getUser();
    if (user) {
      this.username = user.username;
      this.fetchModules();  
    }
  
  }

  fetchModules(): void {
    this.authService.module().subscribe(
      (modulesResponse) => {
        this.modulesList = modulesResponse;
        console.log('Modules:', this.modulesList);
      },
      (error) => {
        console.error('Error fetching modules:', error);
      }
    );
  }

  onModuleClick(moduleId: number, moduleName: string): void {
    this.selectedModuleName = moduleName;
    this.fetchMenu(moduleId);  
    this.isSidenavVisible = true; 
  }

  fetchMenu(moduleId: number): void {
    this.authService.menu(moduleId).subscribe(
      (menuData) => {
        if (menuData && menuData.length > 0) {
          this.menuList = menuData;
          console.log('Menu:', this.menuList);
        } else {
          this.menuList = null;
          this.showError('No menu available for this module');
        }
      },
      (error) => {
        console.error('Error fetching menu:', error);
        this.menuList = null;
        this.showError('Failed to fetch the menu');
      }
    );
  }

  toggleDarkMode() {
    this.isDarkMode = !this.isDarkMode;
    document.body.classList.toggle('dark-mode', this.isDarkMode);
  }

  onLogout() {
    debugger
    const user = this.authService.getUser();

    if (user) {
      const userId = user.userId;
      const username = user.username;

      this.authService.logout(userId, username).subscribe(
        (response) => {
          console.log('Logout successful:', response);

          this.authService.clearUser();

          this.router.navigate(['/login']);
        },
        (error) => {

          this.showError("Error during logout", error);
          this.authService.clearUser();
          this.router.navigate(['/login']);
        }
      );
    } else {
      this.showError("No user data found. Please log in.");
      this.authService.clearUser();
      this.router.navigate(['/login']);
    }
  }

  showError(message: string, error?: any) {
    console.error(message, error);
    this.snackBar.open(message, 'Close', {
      duration: 5000,
      horizontalPosition: 'center',
      verticalPosition: 'top'
    });
  }

  onMenuItemClick(menuUrl: string): void {
    console.log('Menu item clicked:', menuUrl);
    this.router.navigate([menuUrl]);
    this.isSidenavVisible = false; 
  }

  toggleSidenav(): void {
    this.isSidenavVisible = !this.isSidenavVisible;
  }

}
