import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private _authenticated: boolean = false;
  private apiUrl: string = environment.apiUrl;  //

  private _jsonURL_dev = 'assets/settings.Development.json';
  private _jsonURL_prod = 'assets/settings.Production.json';


  constructor(private http: HttpClient) { }

  // Login method
  login(credentials: { username: string, password: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}loginuser`, credentials);  // API call using apiUrl
  }
  register(user: any): Observable<any> {
    return this.http.post(`${this.apiUrl}registerdetails`, user);
  }

  logout(userId: number, username: string): Observable<any> {
    return this.http.post(`${this.apiUrl}logoutid`, { userId, username });
  }
  module(): Observable<any> {
    return this.http.get(`${this.apiUrl}modulesdetails`);
  }
  menu(moduleId: number): Observable<any> {
    debugger
    return this.http.get(`${this.apiUrl}menu/${moduleId}`);
  }

  // Method to check if the user is logged in
  isLoggedIn(): boolean {
    return !!this.getToken();  // Check if a token exists in local storage
  }
  gedIn(): boolean {
    return !!localStorage.getItem('user');
  }
  getToken(): string {
    return localStorage.getItem('token') || '';
  }

  saveToken(token: string): void {
    localStorage.setItem('token', token);
  }

  clearToken(): void {
    localStorage.removeItem('token');
  }

  saveUser(user: { token: string, userId: number, username: string, firstName: string, lastName: string }): void {
    localStorage.setItem('user', JSON.stringify(user));
  }

  getUser(): { token: string, userId: number, username: string, firstName: string, lastName: string } | null {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }

  clearUser(): void {
    localStorage.removeItem('user');
  }
}
