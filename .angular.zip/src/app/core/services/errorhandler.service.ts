import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ErrorHandlerService {
 
    private errorPopupComponent: any;

    constructor() {}
  
    setPopupComponent(component: any) {
      this.errorPopupComponent = component;
    }
  
    showError(message: string): void {
      if (this.errorPopupComponent) {
        this.errorPopupComponent.showError(message);
      }
    }
}
