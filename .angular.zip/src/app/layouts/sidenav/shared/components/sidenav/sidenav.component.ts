import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatListModule } from '@angular/material/list';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';

@Component({
  selector: 'kz-sidenav',
  standalone: true,
  imports: [MatListModule, MatSidenavModule, CommonModule, FormsModule, MatToolbarModule],
  templateUrl: './sidenav.component.html',
  styleUrl: './sidenav.component.scss'
})
export class SidenavComponent {
  @Input() menuList: any[] = [];
  @Output() menuClick = new EventEmitter<string>();
  @Input() selectedModuleName: string = '';

  onMenuClick(menuUrl: string): void {
    this.menuClick.emit(menuUrl);
  }
}
