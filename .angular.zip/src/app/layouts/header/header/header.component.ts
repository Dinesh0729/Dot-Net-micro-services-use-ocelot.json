import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';
import {MatTooltipModule} from '@angular/material/tooltip'

@Component({
  selector: 'kz-header',
  standalone: true,
  imports: [CommonModule, MatToolbarModule, MatIconModule, FormsModule, 
    ReactiveFormsModule, MatMenuModule, MatButtonModule,MatTooltipModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
  @Output() logout = new EventEmitter<void>();
  @Output() toggleDarkMode = new EventEmitter<void>();
  // @Output() moduleClick = new EventEmitter<number>();
  @Output() moduleClick = new EventEmitter<{ moduleId: number, moduleName: string }>(); // Emit both moduleId and moduleName
  @Input() isSidenavVisible: boolean = true;
  @Input() modulesList: any[] = [];
  @Input() username: any;
  @Output() toggleSidenav = new EventEmitter<void>();

  ngOnInit(): void {
    console.log(this.username, 'name')
  }

  onToggleDarkMode() {
    this.toggleDarkMode.emit();
  }
  onLogout() {
    this.logout.emit();
  }
  onModuleClick(moduleId: number, moduleName: string): void {
    this.moduleClick.emit({ moduleId, moduleName });
  }
  onToggleSidenav(): void {
    this.toggleSidenav.emit();
  }
}
