﻿using Domain.Entities;

public interface IUserService
{
    Task<User> AuthenticateAsync(string username, string password);
    Task RegisterAsync(User user);
    Task<bool> LogoutAsync(int userId, string username); // Updated return type
}