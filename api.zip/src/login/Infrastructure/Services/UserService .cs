﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Application.Interfaces;
using Domain.Entities;
using System.Security.Cryptography;
using System.Text;

namespace Infrastructure.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly ITokenService _tokenService;

        public UserService(IUserRepository userRepository, ITokenService tokenService)
        {
            _userRepository = userRepository;
            _tokenService = tokenService;
        }

        public async Task<User> AuthenticateAsync(string username, string password)
        {
            var user = await _userRepository.GetUserByUsernameAsync(username);
            if (user == null || !VerifyPassword(password, user.PasswordHash, user.PasswordKey))
            {
                return null;
            }

            user.Token = _tokenService.GenerateToken(user);  // Generate the token
            await _userRepository.UpdateUserAsync(user);
            return user;
        }

        public async Task RegisterAsync(User user)
        {
            if (await _userRepository.GetUserByUsernameAsync(user.Username) != null)
            {
                throw new Exception("Username is already taken");
            }

            user.PasswordKey = GeneratePasswordKey();
            user.PasswordHash = HashPassword(user.PasswordHash, user.PasswordKey);
            user.CreatedOn = DateTime.UtcNow;
            user.IsActive = true;

            await _userRepository.AddUserAsync(user);
        }

        public async Task<bool> LogoutAsync(int userId, string username)  // Updated return type
        {
            var user = await _userRepository.GetUserByIdAsync(userId);
            if (user == null || user.Username != username)
            {
                return false; // Logout failed
            }

            if (string.IsNullOrEmpty(user.Token))
            {
                return false; // User is not logged in
            }

            // Remove the token to log the user out
            user.Token = null;

            // Update the user in the database
            await _userRepository.UpdateUserAsync(user);
            return true; // Logout successful
        }


        private string GeneratePasswordKey()
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                var key = new byte[32];
                rng.GetBytes(key);
                return Convert.ToBase64String(key);
            }
        }

        private string HashPassword(string password, string key)
        {
            using (var hmac = new HMACSHA256(Convert.FromBase64String(key)))
            {
                var passwordBytes = Encoding.UTF8.GetBytes(password);
                var hash = hmac.ComputeHash(passwordBytes);
                return Convert.ToBase64String(hash);
            }
        }

        private bool VerifyPassword(string password, string storedHash, string storedKey)
        {
            var hash = HashPassword(password, storedKey);
            return hash == storedHash;
        }
    }
}

