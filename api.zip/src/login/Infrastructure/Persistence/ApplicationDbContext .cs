﻿using Microsoft.EntityFrameworkCore;
using Domain.Entities;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Infrastructure.Persistence
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseNpgsql("DefaultConnection");  
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // User entity configuration
            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("usermaster", schema: "flowtechdbv2");  // Specify the table name and schema

                entity.HasKey(e => e.UserId)
                      .HasName("usermaster_pkey");

                entity.Property(e => e.UserId)
                      .HasColumnName("userid")
                      .UseIdentityColumn();

                entity.Property(e => e.FirstName)
                      .HasColumnName("firstname")
                      .HasMaxLength(100)
                      .IsRequired(false);

                entity.Property(e => e.LastName)
                      .HasColumnName("lastname")
                      .HasMaxLength(100)
                      .IsRequired(false);

                entity.Property(e => e.Username)
                      .HasColumnName("username")
                      .HasMaxLength(150)
                      .IsRequired();

                entity.Property(e => e.PasswordHash)
                      .HasColumnName("passwordhash")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.PasswordKey)
                      .HasColumnName("passwordkey")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.EmailId)
                      .HasColumnName("emailid")
                      .HasMaxLength(200)
                      .IsRequired();

                entity.Property(e => e.CreatedOn)
                      .HasColumnName("createdon")
                      .HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.Property(e => e.IsActive)
                      .HasColumnName("isactive")
                      .IsRequired();

                entity.Property(e => e.Token)
                        .HasColumnName("token")
                      .HasMaxLength(400)
                      .IsRequired(false);
           
                modelBuilder.Entity<User>()
                    .HasIndex(u => u.EmailId)
                    .IsUnique()
                    .HasDatabaseName("usermaster_emailid_key");

                modelBuilder.Entity<User>()
                    .HasIndex(u => u.Username)
                    .IsUnique()
                    .HasDatabaseName("usermaster_username_key");
            });
            // Ensure all DateTime fields are stored in UTC
            foreach (var entityType in modelBuilder.Model.GetEntityTypes())
            {
                var dateTimeProperties = entityType.ClrType.GetProperties()
                    .Where(p => p.PropertyType == typeof(DateTime) || p.PropertyType == typeof(DateTime?));

                foreach (var property in dateTimeProperties)
                {
                    modelBuilder.Entity(entityType.ClrType).Property(property.Name)
                        .HasConversion(
                            new ValueConverter<DateTime, DateTime>(
                                v => v.Kind == DateTimeKind.Utc ? v : v.ToUniversalTime(),
                                v => DateTime.SpecifyKind(v, DateTimeKind.Utc)
                            )
                        );
                }
            }
        }
    }
}
