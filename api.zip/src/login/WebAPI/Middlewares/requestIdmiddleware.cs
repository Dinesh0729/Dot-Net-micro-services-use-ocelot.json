﻿namespace WebAPI.Middlewares
{
    public class RequestIdMiddleware
    {
        private readonly RequestDelegate _next;

        public RequestIdMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            if (!context.Request.Headers.ContainsKey("Request-Id"))
            {
                context.Request.Headers["Request-Id"] = Guid.NewGuid().ToString();
            }

            await _next(context);
        }
    }

}
