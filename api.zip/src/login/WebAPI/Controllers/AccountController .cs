﻿using Application.Interfaces;
using Application.DTOs;  // Ensure this using directive is included
using Domain.Entities;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Infrastructure.Repositories;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountController : ControllerBase
    {
        private readonly IUserService _userService;

        public AccountController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto loginDto)
        {
            var requestId = HttpContext.Request.Headers["Request-Id"].ToString();
            if (string.IsNullOrEmpty(requestId))
            {
                requestId = Guid.NewGuid().ToString();
            }

            //var requestId = HttpContext.Request.Headers["Request-Id"].ToString();
            var user = await _userService.AuthenticateAsync(loginDto.Username, loginDto.Password);
            if (user == null)
                return Unauthorized();

            return Ok(new { RequestId = requestId, user.Token, user.UserId,user.Username,user.FirstName,user.LastName });
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterUserDto registerUserDto)
        {
            var user = new User
            {
                FirstName = registerUserDto.FirstName,
                LastName = registerUserDto.LastName,
                Username = registerUserDto.Username,
                PasswordHash = registerUserDto.Password,
                EmailId = registerUserDto.EmailId,
              
            };

            await _userService.RegisterAsync(user);
            return Ok();
        }

        [HttpPost("logout")]
        public async Task<IActionResult> Logout(int userId, string username)
        {
            try
            {
                bool isLoggedOut = await _userService.LogoutAsync(userId, username);

                if (isLoggedOut)
                {
                    return Ok(new { message = "Logout successful" });
                }
                else
                {
                    return BadRequest(new { message = "Logout failed: User is not logged in or user not found" });
                }
            }
            catch (Exception ex)
            {
                
                return BadRequest(new { message = "Logout failed", error = ex.Message });
            }
        }



        //[HttpPost("logout")]
        //public async Task<IActionResult> Logout(int userId, string username)
        //{
        //    try
        //    {
        //        await _userService.LogoutAsync(userId, username);
        //        return Ok(new { message = "Logout successful" });
        //    }
        //    catch (Exception ex)
        //    {
        //        // Log the exception or handle it as needed
        //        return BadRequest(new { message = "Logout failed", error = ex.Message });
        //    }
        //}


        //public async Task<IActionResult> Logout(int userId, string username)
        //{
        //    await _userService.LogoutAsync(userId, username);
        //    return Ok();
        //}
    }
}
