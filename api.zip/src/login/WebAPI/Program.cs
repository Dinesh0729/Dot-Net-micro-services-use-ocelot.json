using Application.Interfaces;
using Infrastructure.Persistence;
using Infrastructure.Repositories;
using Infrastructure.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Ocelot.DependencyInjection;
using Ocelot.Middleware;
using Ocelot.RequestId.Middleware;
using System.Security.Cryptography;
using System.Text;
using WebAPI.Middlewares;

var builder = WebApplication.CreateBuilder(args);

//var key = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32));

builder.Services.AddControllers();
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<ITokenService, TokenService>();

// Add Swagger services (optional, if you're using Swagger)
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Retrieve JWT settings from configuration
var jwtSettings = builder.Configuration.GetSection("JwtSettings");
var secretKey = jwtSettings["SecretKey"];
var issuer = jwtSettings["Issuer"];
var audience = jwtSettings["Audience"];

// Validate the secret key
if (string.IsNullOrEmpty(secretKey))
{
    throw new ArgumentNullException(nameof(secretKey), "JWT SecretKey cannot be null or empty.");
}

// Use the validated secret key to create the security key
var keyBytes = Encoding.UTF8.GetBytes(secretKey);
var securityKey = new SymmetricSecurityKey(keyBytes);

// Configure JWT authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = issuer,
            ValidAudience = audience,
            IssuerSigningKey = securityKey
        };
    });

builder.Services.AddAuthorization();

// Add CORS configuration here
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

//builder.Services.AddOcelot();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
        c.RoutePrefix = string.Empty; // Set Swagger UI at the app's root
    });
}

// Use your custom RequestIdMiddleware
app.UseMiddleware<WebAPI.Middlewares.RequestIdMiddleware>();
// Use the Global Exception Handler Middleware
app.UseMiddleware<GlobalExceptionHandlerMiddleware>();


app.UseHttpsRedirection();

app.UseRouting();

// Add CORS middleware here
app.UseCors("AllowAll");

//app.UseOcelot().Wait();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
