﻿using System.Data;
using Domain.Entities;
using Application.Interfaces;
using Npgsql;

namespace Infrastructure.Repositories
{
    public class ModuleRepository : IModuleRepository
    {
        private readonly string _connectionString;

        public ModuleRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<IEnumerable<Module>> GetModulesByRoleIdAsync(int roleId)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            using var cmd = new NpgsqlCommand("SELECT * FROM flowtechdbv2.fn_get_modules_by_roleid(@p_roleid)", connection);
            cmd.CommandType = CommandType.Text; 
            cmd.Parameters.AddWithValue("p_roleid", roleId);

            await connection.OpenAsync();
            using var reader = await cmd.ExecuteReaderAsync();
            var modules = new List<Module>();
            while (reader.Read())
            {
                modules.Add(new Module
                {
                    ModuleId = Convert.ToInt32(reader["moduleid"]),
                    ModuleName = reader["modulename"].ToString(),
                    Description = reader["description"].ToString(),
                    CreatedOn = Convert.ToDateTime(reader["createdon"])
                });
            }
            return modules;
        }


    }
}
