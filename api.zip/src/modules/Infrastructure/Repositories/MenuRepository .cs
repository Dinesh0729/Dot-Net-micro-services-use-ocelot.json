﻿using Application.Interfaces;
using Domain.Entities;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Repositories
{
    public class MenuRepository : IMenuRepository
    {
        private readonly string _connectionString;

        public MenuRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<IEnumerable<Menu>> GetMenusByModuleIdAsync(int moduleId)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            using var cmd = new NpgsqlCommand("SELECT * FROM flowtechdbv2.fn_get_menus_by_moduleid(@p_moduleid)", connection);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("p_moduleid", moduleId);

            await connection.OpenAsync();
            using var reader = await cmd.ExecuteReaderAsync();
            var menus = new List<Menu>();
            while (reader.Read())
            {
                menus.Add(new Menu
                {
                    MenuId = Convert.ToInt32(reader["menuid"]),
                    MenuName = reader["menuname"].ToString(),
                    MenuUrl = reader["menuurl"].ToString(),
                    MenuIcon = reader["menuicon"].ToString(),
                    MenuOrder = reader["menuorder"] as int?,
                    ParentMenu = reader["parentmenu"] as int?,
                    IsActive = Convert.ToBoolean(reader["isactive"]),
                    CreatedBy = Convert.ToInt32(reader["createdby"]),
                    CreatedOn = Convert.ToDateTime(reader["createdon"]),
                    ModifiedBy = reader["modifiedby"] as int?,
                    ModifiedOn = reader["modifiedon"] as DateTime?,
                    ProcessPrivilege = reader["processprivilege"].ToString()
                });
            }
            return menus;
        }


        public async Task AddMenuAsync(Menu menu)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            using var cmd = new NpgsqlCommand("flowtechdbv2.sp_add_menu", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("p_menuname", menu.MenuName);
            cmd.Parameters.AddWithValue("p_menuurl", menu.MenuUrl);
            cmd.Parameters.AddWithValue("p_menuicon", menu.MenuIcon);
            cmd.Parameters.AddWithValue("p_menuorder", menu.MenuOrder);
            cmd.Parameters.AddWithValue("p_parentmenu", menu.ParentMenu);
            cmd.Parameters.AddWithValue("p_isactive", menu.IsActive);
            cmd.Parameters.AddWithValue("p_createdby", menu.CreatedBy);

            await connection.OpenAsync();
            await cmd.ExecuteNonQueryAsync();
        }

        public async Task UpdateMenuAsync(Menu menu)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            using var cmd = new NpgsqlCommand("flowtechdbv2.sp_update_menu", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("p_menuid", menu.MenuId);
            cmd.Parameters.AddWithValue("p_menuname", menu.MenuName);
            cmd.Parameters.AddWithValue("p_menuurl", menu.MenuUrl);
            cmd.Parameters.AddWithValue("p_menuicon", menu.MenuIcon);
            cmd.Parameters.AddWithValue("p_menuorder", menu.MenuOrder);
            cmd.Parameters.AddWithValue("p_parentmenu", menu.ParentMenu);
            cmd.Parameters.AddWithValue("p_isactive", menu.IsActive);
            cmd.Parameters.AddWithValue("p_modifiedby", menu.ModifiedBy);

            await connection.OpenAsync();
            await cmd.ExecuteNonQueryAsync();
        }

        public async Task DeleteMenuAsync(int menuId)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            using var cmd = new NpgsqlCommand("flowtechdbv2.sp_delete_menu", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("p_menuid", menuId);

            await connection.OpenAsync();
            await cmd.ExecuteNonQueryAsync();
        }
    }
}
