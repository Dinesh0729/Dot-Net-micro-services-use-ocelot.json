﻿using System.Data;
using Domain.Entities;
using Application.Interfaces;
using Npgsql;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Infrastructure.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly string _connectionString;

        public UserRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<User> GetUserByUsernameAsync(string username)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            using var cmd = new NpgsqlCommand("flowtechdbv2.sp_get_user_by_username", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("p_username", username);

            await connection.OpenAsync();
            using var reader = await cmd.ExecuteReaderAsync();
            return reader.Read() ? MapToUser(reader) : null;
        }

        public async Task<User> GetUserByIdAsync(int userId)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            using var cmd = new NpgsqlCommand("SELECT * FROM flowtechdbv2.fn_get_user_by_id(@p_userId)", connection);
            cmd.CommandType = CommandType.Text;  // Use CommandType.Text for functions
            cmd.Parameters.AddWithValue("p_userId", userId);

            await connection.OpenAsync();
            using var reader = await cmd.ExecuteReaderAsync();
            return reader.Read() ? MapToUser(reader) : null;
        }



        public async Task AddUserAsync(User user)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            using var cmd = new NpgsqlCommand("flowtechdbv2.sp_add_user", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("p_username", user.Username);
            cmd.Parameters.AddWithValue("p_passwordHash", user.PasswordHash);
            cmd.Parameters.AddWithValue("p_passwordKey", user.PasswordKey);
            cmd.Parameters.AddWithValue("p_emailId", user.EmailId);

            await connection.OpenAsync();
            await cmd.ExecuteNonQueryAsync();
        }

        public async Task UpdateUserAsync(User user)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            using var cmd = new NpgsqlCommand("flowtechdbv2.sp_update_user", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("p_userId", user.UserId);
            cmd.Parameters.AddWithValue("p_username", user.Username);
            cmd.Parameters.AddWithValue("p_passwordHash", user.PasswordHash);
            cmd.Parameters.AddWithValue("p_passwordKey", user.PasswordKey);
            cmd.Parameters.AddWithValue("p_emailId", user.EmailId);

            await connection.OpenAsync();
            await cmd.ExecuteNonQueryAsync();
        }

        public async Task<IEnumerable<Role>> GetRolesByUserIdAsync(int userId)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            using var cmd = new NpgsqlCommand("SELECT * FROM flowtechdbv2.fn_get_roles_by_userid(@p_userid)", connection);
            cmd.CommandType = CommandType.Text;  // Use CommandType.Text for functions
            cmd.Parameters.AddWithValue("p_userid", userId);

            await connection.OpenAsync();
            using var reader = await cmd.ExecuteReaderAsync();
            var roles = new List<Role>();
            while (reader.Read())
            {
                roles.Add(new Role
                {
                    RoleId = Convert.ToInt32(reader["roleid"]),
                    RoleName = reader["rolename"].ToString(),
                    Description = reader["description"].ToString(),
                    CreatedOn = Convert.ToDateTime(reader["createdon"])
                });
            }
            return roles;
        }


        private User MapToUser(IDataReader reader)
        {
            return new User
            {
                UserId = Convert.ToInt32(reader["userid"]),
                Username = reader["username"].ToString() ?? string.Empty,
                PasswordHash = reader["passwordhash"].ToString() ?? string.Empty,
                PasswordKey = reader["passwordkey"].ToString() ?? string.Empty,
                EmailId = reader["emailid"].ToString() ?? string.Empty,
                CreatedOn = Convert.ToDateTime(reader["createdon"]),
                IsActive = Convert.ToBoolean(reader["isactive"]),
                Token = reader["token"]?.ToString()
            };
        }
    }
}
