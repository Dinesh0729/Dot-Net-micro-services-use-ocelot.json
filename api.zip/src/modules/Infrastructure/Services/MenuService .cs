﻿using Application.Interfaces;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class MenuService : IMenuService
    {
        private readonly IMenuRepository _menuRepository;

        public MenuService(IMenuRepository menuRepository)
        {
            _menuRepository = menuRepository;
        }

        public async Task<IEnumerable<Menu>> GetMenusByModuleIdAsync(int moduleId)
        {
            return await _menuRepository.GetMenusByModuleIdAsync(moduleId);
        }

        public async Task AddMenuAsync(Menu menu)
        {
            await _menuRepository.AddMenuAsync(menu);
        }

        public async Task UpdateMenuAsync(Menu menu)
        {
            await _menuRepository.UpdateMenuAsync(menu);
        }

        public async Task DeleteMenuAsync(int menuId)
        {
            await _menuRepository.DeleteMenuAsync(menuId);
        }
    }
}
