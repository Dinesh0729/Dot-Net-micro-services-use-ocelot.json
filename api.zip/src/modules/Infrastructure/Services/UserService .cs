﻿using System.Security.Cryptography;
using System.Text;
using Application.Interfaces;
using Domain.Entities;

namespace Infrastructure.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IModuleRepository _moduleRepository;

        public UserService(IUserRepository userRepository, IModuleRepository moduleRepository)
        {
            _userRepository = userRepository;
            _moduleRepository = moduleRepository;
        }

        public async Task<User> AuthenticateAsync(string username, string password)
        {
            var user = await _userRepository.GetUserByUsernameAsync(username);
            if (user == null || !VerifyPassword(password, user.PasswordHash, user.PasswordKey))
            {
                return null;
            }

            return user; // Token already generated and stored in the login process
        }

        public async Task RegisterAsync(User user)
        {
            if (await _userRepository.GetUserByUsernameAsync(user.Username) != null)
            {
                throw new Exception("Username is already taken");
            }

            user.PasswordKey = GeneratePasswordKey();
            user.PasswordHash = HashPassword(user.PasswordHash, user.PasswordKey);
            user.CreatedOn = DateTime.UtcNow;
            user.IsActive = true;

            await _userRepository.AddUserAsync(user);
        }

        public async Task<bool> LogoutAsync(int userId, string username)
        {
            var user = await _userRepository.GetUserByIdAsync(userId);
            if (user == null || user.Username != username)
            {
                return false;
            }

            user.Token = null;
            await _userRepository.UpdateUserAsync(user);
            return true;
        }

        public async Task<IEnumerable<Module>> GetAuthorizedModulesAsync(int userId)
        {
            var user = await _userRepository.GetUserByIdAsync(userId);
            if (user == null || !user.IsActive)
            {
                throw new UnauthorizedAccessException("User not authorized or not found");
            }

          
            var roles = await _userRepository.GetRolesByUserIdAsync(userId);
            var modules = new List<Module>();

            foreach (var role in roles)
            {
                var roleModules = await _moduleRepository.GetModulesByRoleIdAsync(role.RoleId);
                modules.AddRange(roleModules);
            }

            return modules.Distinct();
        }

        private string GeneratePasswordKey()
        {
            using var rng = new RNGCryptoServiceProvider();
            var key = new byte[32];
            rng.GetBytes(key);
            return Convert.ToBase64String(key);
        }

        private string HashPassword(string password, string key)
        {
            using var hmac = new HMACSHA256(Convert.FromBase64String(key));
            var passwordBytes = Encoding.UTF8.GetBytes(password);
            var hash = hmac.ComputeHash(passwordBytes);
            return Convert.ToBase64String(hash);
        }

        private bool VerifyPassword(string password, string storedHash, string storedKey)
        {
            var hash = HashPassword(password, storedKey);
            return hash == storedHash;
        }
    }
}
