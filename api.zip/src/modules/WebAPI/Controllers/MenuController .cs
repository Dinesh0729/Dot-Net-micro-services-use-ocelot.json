﻿using Application.Interfaces;
using Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class MenuController : ControllerBase
    {
        private readonly IMenuService _menuService;

        public MenuController(IMenuService menuService)
        {
            _menuService = menuService ?? throw new ArgumentNullException(nameof(menuService));

        }

        [HttpGet("by-module/{moduleId}")]
        public async Task<IActionResult> GetMenusByModuleId(int moduleId)
        {
            var menus = await _menuService.GetMenusByModuleIdAsync(moduleId);
            return Ok(menus);
        }

        [HttpPost]
        public async Task<IActionResult> AddMenu(Menu menu)
        {
            await _menuService.AddMenuAsync(menu);
            return CreatedAtAction(nameof(GetMenusByModuleId), new { moduleId = menu.MenuId }, menu);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateMenu(int id, Menu menu)
        {
            if (id != menu.MenuId)
            {
                return BadRequest();
            }

            await _menuService.UpdateMenuAsync(menu);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMenu(int id)
        {
            await _menuService.DeleteMenuAsync(id);
            return NoContent();
        }
    }
}
