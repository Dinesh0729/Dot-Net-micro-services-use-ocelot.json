﻿using Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] 
    public class ModuleController : ControllerBase
    {
        private readonly IUserService _userService;

        public ModuleController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet("modules")]
        public async Task<IActionResult> GetModules()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim))
            {
                return Unauthorized();
            }

            int userId = int.Parse(userIdClaim);

            var modules = await _userService.GetAuthorizedModulesAsync(userId);
            return Ok(modules);
        }
    }
}
